<template>
  <q-page class="q-pa-md">
    <div class="page-header q-mb-lg">
      <h1 class="text-h4 text-weight-bold q-mb-xs">Zodiac Insights</h1>
      <p class="text-body2 text-grey-7">
        Discover your Chinese Zodiac sign, element, and harmonious pairings
      </p>
    </div>

    <q-card flat bordered class="q-mb-md">
      <q-card-section>
        <div class="text-h6 q-mb-md">Enter Your Birth Date</div>

        <div v-if="zodiacData" class="q-mb-md">
          <q-btn unelevated color="primary" style="text-transform: none;" icon="casino" label="Generate Lucky Numbers"
            class="full-width" size="lg" @click="goToGenerator" />
        </div>

        <q-date v-model="selectedDate" mask="YYYY-MM-DD" :options="dateOptions" class="full-width"
          @update:model-value="handleDateChange" />
      </q-card-section>
    </q-card>

    <div v-if="zodiacData">
      <q-card flat bordered class="q-mb-md zodiac-card">
        <q-card-section class="bg-gradient text-white">
          <div class="text-center">
            <h2 class="text-h3 text-weight-bold q-mt-md q-mb-sm">
              {{ zodiacData.sign }}
            </h2>
            <div class="text-h6">{{ zodiacData.element }} Element</div>
          </div>
        </q-card-section>

        <q-separator />

        <q-card-section>
          <div class="text-h6 q-mb-md">Key Characteristics</div>
          <div class="characteristics-grid">
            <q-chip v-for="trait in zodiacData.characteristics" :key="trait" color="primary" text-color="white">
              {{ trait }}
            </q-chip>
          </div>
        </q-card-section>
      </q-card>

      <q-card flat bordered class="q-mb-md">
        <q-card-section>
          <div class="text-h6 q-mb-md">
            <q-icon name="favorite" color="pink" size="md" class="q-mr-sm" />
            Trine Family Compatibility
          </div>

          <q-banner class="bg-pink-1 q-mb-md">
            <div class="text-body1 text-weight-medium q-mb-sm">
              Your Harmonious Signs:
              <span class="text-primary text-weight-bold">
                {{ zodiacData.trineFamily.join(' & ') }}
              </span>
            </div>
            <div class="text-body2 text-grey-8">
              {{ zodiacData.compatibility }}
            </div>
          </q-banner>

          <div class="trine-symbols">
            <div class="trine-item">
              <q-avatar size="60px" color="primary" text-color="white" class="q-mb-sm">
                <q-icon name="star" size="32px" />
              </q-avatar>
              <div class="text-weight-bold">{{ zodiacData.sign }}</div>
              <div class="text-caption text-grey-7">Your Sign</div>
            </div>

            <q-icon name="favorite" style="transform: rotate(0deg);" color="pink" size="24px" class="connector" />

            <div class="row q-gutter-lg">
              <div class="trine-item" v-for="compatible in zodiacData.trineFamily" :key="compatible">
                <q-avatar size="60px" color="pink" text-color="white" class="q-mb-sm">
                  <q-icon name="pets" size="32px" />
                </q-avatar>
                <div class="text-weight-bold">{{ compatible }}</div>
                <div class="text-caption text-grey-7">Compatible</div>
              </div>
            </div>
          </div>
        </q-card-section>
      </q-card>

      <q-card flat bordered class="q-mb-md">
        <q-card-section>
          <div class="text-h6 q-mb-md">
            <q-icon name="casino" color="amber" size="md" class="q-mr-sm" />
            Lucky Numbers
          </div>

          <div class="lucky-numbers">
            <div v-for="num in zodiacData.luckyNumbers" :key="num" class="lucky-number">
              {{ num }}
            </div>
          </div>

          <q-banner class="bg-amber-1 q-mt-md">
            <template v-slot:avatar>
              <q-icon name="lightbulb" color="amber-8" />
            </template>
            <div class="text-caption">
              Use these lucky numbers when playing the lottery or making important decisions
            </div>
          </q-banner>
        </q-card-section>
      </q-card>

      <q-card flat bordered class="q-mb-md">
        <q-card-section>
          <div class="text-h6 q-mb-md">
            <q-icon name="event" color="green" size="md" class="q-mr-sm" />
            Auspicious Months
          </div>

          <div class="months-grid">
            <q-chip v-for="month in zodiacData.auspiciousMonths" :key="month" color="green" text-color="white"
              icon="event" size="md">
              {{ month }}
            </q-chip>
          </div>

          <q-banner class="bg-green-1 q-mt-md">
            <template v-slot:avatar>
              <q-icon name="info" color="green-8" />
            </template>
            <div class="text-caption">
              These months carry especially favorable energy for you
            </div>
          </q-banner>
        </q-card-section>
      </q-card>

      <q-card flat bordered class="q-mb-md">
        <q-card-section>
          <div class="text-h6 q-mb-md">
            <q-icon name="home" color="deep-purple" size="md" class="q-mr-sm" />
            Feng Shui Tips
          </div>

          <q-list separator>
            <q-item v-for="(tip, index) in zodiacData.fengShuiTips" :key="index">
              <q-item-section avatar>
                <q-avatar color="deep-purple" text-color="white" size="32px">
                  {{ index + 1 }}
                </q-avatar>
              </q-item-section>
              <q-item-section>
                <q-item-label>{{ tip }}</q-item-label>
              </q-item-section>
            </q-item>
          </q-list>
        </q-card-section>
      </q-card>

      <q-card flat bordered class="manifestation-card">
        <q-card-section class="bg-deep-purple-1">
          <div class="text-h6 q-mb-md">
            <q-icon name="psychology" color="deep-purple" size="md" class="q-mr-sm" />
            Manifestation & Mindset Guidance
          </div>

          <div class="manifestation-content">
            <q-icon name="format_quote" size="48px" color="deep-purple-3" class="quote-icon" />
            <p class="text-body1 text-center q-px-md">
              {{ zodiacData.manifestationGuidance }}
            </p>
          </div>

          <q-separator class="q-my-md" />

          <div class="text-center">
            <q-btn flat color="deep-purple" icon="share" label="Share Your Insights" @click="shareInsights" />
          </div>
        </q-card-section>
      </q-card>
    </div>

    <div v-else class="text-center q-pa-xl">
      <q-icon name="calendar_today" size="64px" color="grey-5" />
      <p class="text-h6 text-grey-7 q-mt-md">
        Select your birth date to see your zodiac insights
      </p>
    </div>
  </q-page>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { useQuasar } from 'quasar';
import { useRouter } from 'vue-router';
import { useZodiac } from '../composables/useZodiac';

const $q = useQuasar();
const router = useRouter();
const { birthDate, zodiacResult } = useZodiac();

const selectedDate = ref('');

const dateOptions = (date: string) => {
  const year = parseInt(date.split('/')[0]);
  return year >= 1900 && year <= 2031;
};

const handleDateChange = (value: string) => {
  if (value) {
    const date = new Date(value);
    birthDate.value = date;
  }
};

const zodiacData = computed(() => {
  return zodiacResult.value;
});

const shareInsights = () => {
  if (!zodiacData.value) return;

  const text = `My Chinese Zodiac: ${zodiacData.value.sign} (${zodiacData.value.element} Element)
Compatible with: ${zodiacData.value.trineFamily.join(' & ')}
Lucky Numbers: ${zodiacData.value.luckyNumbers.join(', ')}

${zodiacData.value.manifestationGuidance}`;

  if (navigator.share) {
    navigator.share({
      title: 'My Zodiac Insights',
      text: text,
    }).catch(() => {
      copyToClipboard(text);
    });
  } else {
    copyToClipboard(text);
  }
};

const copyToClipboard = (text: string) => {
  navigator.clipboard.writeText(text).then(() => {
    $q.notify({
      type: 'positive',
      message: 'Insights copied to clipboard!',
      position: 'top',
    });
  });
};

const goToGenerator = () => {
  router.push({ name: 'generate' });
};
</script>

<style scoped>
.page-header {
  border-bottom: 2px solid #e0e0e0;
  padding-bottom: 16px;
}

.zodiac-card {
  overflow: hidden;
}

.bg-gradient {
  background: linear-gradient(135deg, #327c4b 0%, #50C878 100%);
}

.characteristics-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.trine-symbols {
  display: flex;
  align-items: center;
  justify-content: space-around;
  flex-wrap: wrap;
  gap: 16px;
  padding: 24px 0;
}

.trine-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.connector {
  margin: 0 8px;
}

.lucky-numbers {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  justify-content: center;
  padding: 16px 0;
}

.lucky-number {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 20px;
  box-shadow: 0 2px 8px rgba(255, 170, 0, 0.3);
}

.months-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.manifestation-content {
  position: relative;
  padding: 32px 16px;
}

.quote-icon {
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  opacity: 0.3;
}

.manifestation-card {
  border: 2px solid #673ab7;
}

@media (max-width: 600px) {
  .trine-symbols {
    flex-direction: column;
  }

  .connector {
    transform: rotate(90deg);
    margin: 8px 0;
  }
}
</style>
